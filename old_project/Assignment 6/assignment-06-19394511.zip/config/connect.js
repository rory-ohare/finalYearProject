module.exports = {
    database: {
        url: "mongodb+srv://admin:011235813@cluster0.3izzb.mongodb.net/assignment5?"
    }
}